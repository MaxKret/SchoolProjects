extract_words.py:
	must be run with: "extract_words.py < extract_words.txt". This is the txt file for the novel, Frankenstein.

a3_novelvisualization.pde
	open the .pde file and click 'Run' to display the image. 
	Clicking the mouse will change which words are displayed. 
	Entering chars from your keyboard will change words displayed to only display words with the sub-string of entered 
	text contained. 
	To Reset the string you have entered press enter/return.
	
a3_wordfrequency.pde
	open the .pde file and click 'Run' to display the graph